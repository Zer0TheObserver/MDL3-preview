# MDL3 3.0.0-dev.47 预览版与 HD2 Data Hub

## 包里有什么

- **MDL3**：在游戏里管理模组和设置。按 ESC，菜单里会多出“MDL3 设置”一页。
- **HD2 Data Hub 0.6.0**：给其他模组提供游戏数据，可以单独开关；使用时请同时启用 MDL3。
- **MDL3Setup.exe**：安装与修复工具（安装/更新组件、修复 EAC 证书、修复 EAC 服务、诊断报告、彻底清除），见下文。
- **For Modder 文件夹**：给模组作者的 HD2 Data Hub 接口文档（`hd2data_field_reference_v0_6_0.md`，列出 `HD2Data` 的全部函数和字段），以及 MDL3 音频接口说明（`MDL3_AUDIO_API_zh.md`，含句柄、3D 定位、混响；**所有 mod 合计最多同时 3 种不同的混响设置**），MDL3 绘图接口说明（`MDL3_GUI_API_zh.md`，矩形、线、圆、文字、图片）图片转换工具 `gui_assets.py` 和音频转换工具 `audio_assets.py`（含 `audio_adpcm.py`）。普通玩家不需要。

## 安装或更新

1. 在 Arsenal 中导入本 ZIP（替换旧的 MDL3 包），分别勾选 MDL3 和 HD2 Data Hub，然后点 Deploy。
2. **把 MDL3 放在 Arsenal 的最高优先级（最后部署）。** 游戏只运行优先级最高的启动脚本，自带启动脚本的模组排在 MDL3 后面时，MDL3 不会启动。
3. 不要同时启用原先单独安装的 HD2 Data Hub。
4. 通过 Steam 正常启动游戏，按 ESC：
   - 出现“MDL3 设置”一页：安装完成。
   - 出现“MDL3 诊断模式”窗口：第一次使用或刚更新时，MDL3 会自动安装自己的组件。按窗口提示**完全退出游戏再启动一次**即可。

已有的授权和设置会保留，被替换的旧组件会保存为 `mdl_native_bridge.dll.old`。

也可以先退出游戏，把 ZIP 解压出来，**直接双击 `MDL3Setup.exe`**（不要“以管理员身份运行”），点“安装 / 更新”。它会自动找到游戏；找不到时点“选择…”指定游戏目录（包含 bin 和 data 的文件夹）。

**文件位置（本版起）**：MDL3 的组件、设置和日志统一放在 `C:\ProgramData\MDL3`（日志在 `C:\ProgramData\MDL3\Logs`），MDL 的设置和本地模组在 `C:\ProgramData\MDL\Helldivers2`，与用户名无关，中文或其他文字的用户名都不受影响。以前装在用户目录（`%LOCALAPPDATA%\MDL3`）的旧版本照常可用；运行一次 MDL3Setup.exe 会把原来的设置和本地模组迁移过来。

## 功能说明

- **HD2 Data Hub 0.6.0**：新增背包状态（各种背包的类型、充能、冷却等）、增强剂与状态效果、房间信息等数据，供需要的模组使用。
- **模组音效**：所有模组的音效缓存合计可达 512 MB，单个音效约 9 MB 以内。本版起模组还可以暂停/继续/循环播放、按位置播放 3D 音效（随距离和方向变化），以及给音效加混响（洞穴、大厅等环境）。为控制开销，**所有模组合计同一时间最多 3 种不同的混响环境**，超出时后来的模组没有新的混响，声音照常播放。
- **模组绘图（新）**：MDL3 提供绘图接口 `MDL3.gui`，模组可以在屏幕上画面板、文字、图形和图片，不依赖其他前置。MDL3 会先检查模组传来的参数，传错时只报错、不让游戏崩溃；模组关闭时，它画的东西会自动清除。
- **菜单显示**：如果 MDL3 菜单显示异常，可以在 `C:\ProgramData\MDL\Helldivers2\MDL.cfg`（旧版安装在 `%LOCALAPPDATA%\MDL\Helldivers2\MDL.cfg`）的 `ui` 表里加一行 `incremental_draw = false,`，菜单会改为每次整页重画。

## 进游戏后没有“MDL3 设置”

按 ESC 时如果出现“MDL3 诊断模式”窗口，按窗口里的提示做即可：

- **提示“MDL3 组件已安装，但被游戏的反作弊（EAC）拦截了”**（常见于错误 193 或 EAC“不受信任的系统文件”提示）：最常见的原因是电脑缺少 MDL3 签名所用的中间证书 Certum Code Signing 2021 CA。这是正规证书颁发机构的证书，安装它不会关闭任何安全功能。
  - **推荐**：退出游戏，双击 `MDL3Setup.exe`，点“修复 EAC 证书”（Windows 会弹出管理员确认，点“是”），完成后**重启电脑**，再进游戏按 ESC 看。
  - 也可以在游戏里按 **F1** 安装证书，或按 **F2** 打开修复文件夹。少数电脑在游戏里执行这些操作时游戏会停顿或无响应，遇到这种情况请改用 MDL3Setup.exe。

MDL3Setup.exe 里的其他按钮：

- **修复 EAC 服务**（需要管理员权限）：打开游戏自带的 Easy Anti-Cheat 安装程序，选择 HELLDIVERS 2，点左下角的“修复服务”（Repair Service），然后再进游戏看。
- **生成诊断报告**：只读取信息，不会改动电脑。桌面上会生成一个 `MDL3-report-…txt`（含证书、签名检查、文件位置和日志末尾）。

**只有证书和 EAC 服务都修复过、进游戏仍然没有“MDL3 设置”时**，才需要把诊断报告发给作者。

修复证书不会关闭任何安全功能，也不会改动 EAC 或游戏文件。关闭杀毒软件、添加白名单、换安装目录、重装 MDL3，对这个问题都没有用，不需要做。

如果杀毒软件拦截了 MDL3Setup.exe：它是用 PyInstaller 打包的 Python 程序，这类程序偶尔会被误报。也可以不用它，按上面的步骤在游戏里自动安装。

## 移除

先在 Arsenal 中关闭或移除本包并重新部署。要删掉电脑上的 MDL3 文件，退出游戏后运行 `MDL3Setup.exe`，点“彻底清除…”：

- 默认删除 MDL3 组件、配置和日志（`C:\ProgramData\MDL3` 和用户目录下的 `MDL3` 文件夹）；
- 勾选“同时删除 MDL 模组设置、日志和散装模组”会一并删除 `MDL\Helldivers2`、`CowboyBingus\Helldivers2`、`HD2Runtime\mod_data`（两个位置都删）；
- 勾选“同时移除之前添加的证书”会撤销修复证书时装的证书（需要管理员权限）。

---

Based on Prometheus by Elias Oelschner, https://github.com/prometheus-lua/Prometheus

诊断窗口的文字由 Noto Sans CJK SC 预先渲染（SIL Open Font License 1.1）。
