"""MDL3.gui images: PNG files -> a boot patch with one texture + one GUI material per picture (and, optionally, the
mod's own HD2-Addon Lua files, so that the mod ships as one patch).

    python gui_assets.py --mod mods/your_name/your_mod logo.png arrow.png --lua your_mod.lua --out build

Writes build/data/9ba626afa44a3aa3.patch_0 (+ .gpu_resources, .stream) and build/images.txt. Put the data folder in
your mod package (manifest "Include": ["data"]). In the mod:

    canvas:image('mods/your_name/your_mod/img/logo', x, y, w, h)

Pictures: RGBA, any size up to 4096 (powers of two are best: 64, 128, 256, 512...), straight (not premultiplied)
alpha. Full mip chain, uncompressed (4 bytes per pixel, plus a third for mips): keep pictures small.
Needs Pillow (pip install pillow). Formats: the ones Image Test 0.1.1 showed working in game (2026-11-06).
"""
import argparse
import struct
import sys
from pathlib import Path

LUA_TYPE = 0xA14E8DFA2CD117E2
ARCHIVE = '9ba626afa44a3aa3.patch_0'
GUI_MATERIAL = {0x00: 0x120, 0x04: 1, 0x08: 0x18, 0x0C: 0x7C, 0x40: 1, 0x80: 0xBA25DE35, 0x88: 0x3AA8B87E}
GUI_TEXTURE_AT = 0x8C
MAX_SIDE = 4096


def resource_hash(name):
    """Seed-zero MurmurHash64A of a resource name (Stingray)."""
    data = name.encode('utf-8')
    mask, mix = (1 << 64) - 1, 0xC6A4A7935BD1E995
    value = len(data) * mix & mask
    end = len(data) // 8 * 8
    for (word,) in struct.iter_unpack('<Q', data[:end]):
        word = word * mix & mask
        word ^= word >> 47
        value = (value ^ (word * mix & mask)) * mix & mask
    if data[end:]:
        value = (value ^ int.from_bytes(data[end:], 'little')) * mix & mask
    value ^= value >> 47
    value = value * mix & mask
    return value ^ (value >> 47)


TEXTURE_TYPE = resource_hash('texture')
MATERIAL_TYPE = resource_hash('material')


def rgba_texture(width, height, levels):
    """Texture resource: 192-byte header + DDS/DX10 header, R8G8B8A8_UNORM 2D, `levels` mips in .gpu_resources."""
    head = bytearray(192)
    struct.pack_into('<I', head, 8, 0xFFFFFFFF)
    dds = bytearray(148)
    dds[0:4] = b'DDS '
    struct.pack_into('<7I', dds, 4, 124, 0x00021007, height, width, width * 4, 0, levels)
    struct.pack_into('<2I4s', dds, 4 + 72, 32, 4, b'DX10')
    struct.pack_into('<I', dds, 4 + 104, 0x00401008)
    struct.pack_into('<5I', dds, 128, 28, 3, 0, 1, 0)
    return bytes(head + dds)


def gui_material(texture_id):
    """160 bytes, layout of core/performance_hud/debug: texture table of one entry pointing at the texture."""
    data = bytearray(160)
    for at, value in GUI_MATERIAL.items():
        struct.pack_into('<I', data, at, value)
    struct.pack_into('<Q', data, GUI_TEXTURE_AT, texture_id)
    return bytes(data)


def make_archive(rows_in):
    """Patch archive from [(type, name, data, gpu_data)]: grouped by type (ascending), by name within a type."""
    rows_in = sorted(rows_in, key=lambda r: (r[0], r[1]))
    types = sorted({r[0] for r in rows_in})
    count = len(rows_in)
    offset = (72 + 32 * len(types) + 80 * count + 15) & ~15
    body, gpu, rows = bytearray(offset), bytearray(), bytearray()
    for index, (kind, name, data, gdata) in enumerate(rows_in):
        goff = 0
        if gdata:
            gpu += b'\0' * (-len(gpu) % 64)
            goff = len(gpu)
            gpu += gdata
        gpu_align = 16 if kind == LUA_TYPE else 64
        rows += struct.pack('<7Q6I', name, kind, offset, 0, goff, 0, 0, len(data), 0, len(gdata or b''), 16, gpu_align, index)
        body += data
        body += b'\0' * (-len(body) % 16)
        offset = len(body)
    header = struct.pack('<III20sQQ24s', 0xF0000011, len(types), count, b'', offset, 0, b'')
    type_rows = b''.join(struct.pack('<IIQIIII', 0, 0, t, sum(1 for r in rows_in if r[0] == t), 0, 16,
                                     16 if t == LUA_TYPE else 64) for t in types)
    table = header + type_rows + rows
    body[:len(table)] = table
    return bytes(body), bytes(gpu)


def picture_rows(mod, path):
    from PIL import Image
    image = Image.open(path).convert('RGBA')
    w, h = image.size
    if w > MAX_SIDE or h > MAX_SIDE:
        raise SystemExit('%s: %dx%d is over %d' % (path, w, h, MAX_SIDE))
    if w & (w - 1) or h & (h - 1):
        print('note: %s is %dx%d; powers of two (64, 128, 256...) scale most cleanly' % (path.name, w, h))
    levels, level = [], image
    while True:
        levels.append(level.tobytes())
        if level.size == (1, 1):
            break
        level = level.resize((max(1, level.size[0] // 2), max(1, level.size[1] // 2)), Image.BOX)
    name = mod + '/img/' + path.stem
    tex_id, mat_id = resource_hash(name + '/tex'), resource_hash(name)
    return name, mat_id, [(TEXTURE_TYPE, tex_id, rgba_texture(w, h, len(levels)), b''.join(levels)),
                          (MATERIAL_TYPE, mat_id, gui_material(tex_id), b'')]


def lua_row(path):
    source = Path(path).read_bytes()
    first = source.split(b'\n', 1)[0].strip()
    if not first.startswith(b'-- HD2-Addon: '):
        raise SystemExit('%s: first line must be "-- HD2-Addon: mods/..." (the resource name)' % path)
    name = first[len(b'-- HD2-Addon: '):].decode('utf-8').strip()
    return name, (LUA_TYPE, resource_hash(name), struct.pack('<II', len(source), 2) + source, b'')


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split('\n\n')[0])
    ap.add_argument('--mod', required=True, help='resource folder of your mod, e.g. mods/your_name/your_mod')
    ap.add_argument('--lua', action='append', default=[], help='HD2-Addon Lua file to put in the same patch (repeatable)')
    ap.add_argument('--out', default='build', help='output folder (default build)')
    ap.add_argument('pictures', nargs='*', type=Path)
    a = ap.parse_args(argv)
    mod = a.mod.strip('/')
    if not mod.startswith('mods/') or ' ' in mod:
        raise SystemExit('--mod must look like mods/your_name/your_mod')
    rows, names, seen = [], [], set()
    for path in a.pictures:
        name, mat_id, extra = picture_rows(mod, path)
        if name in seen:
            raise SystemExit('two pictures named ' + path.stem)
        seen.add(name)
        rows += extra
        names.append('%s  (material id %016x)' % (name, mat_id))
    for path in a.lua:
        name, row = lua_row(path)
        rows.append(row)
        names.append('lua ' + name)
    if not rows:
        raise SystemExit('nothing to pack')
    patch, gpu = make_archive(rows)
    data = Path(a.out) / 'data'
    data.mkdir(parents=True, exist_ok=True)
    (data / ARCHIVE).write_bytes(patch)
    (data / (ARCHIVE + '.gpu_resources')).write_bytes(gpu)
    (data / (ARCHIVE + '.stream')).write_bytes(b'')
    (Path(a.out) / 'images.txt').write_text('\n'.join(names) + '\n', encoding='utf-8')
    print('\n'.join(names))
    print('wrote %s (%d resources, %d KiB of pictures)' % (data / ARCHIVE, len(rows), len(gpu) // 1024))
    return 0


if __name__ == '__main__':
    sys.exit(main())
