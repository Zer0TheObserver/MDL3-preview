"""Build MDL3.audio Lua assets from PCM16 WAVs. No runtime audio decoding."""
from pathlib import Path
import argparse
import array
import base64
import json
import re
import struct
import sys
import wave


def build_assets(inputs, codec='pcm16'):
    if not 1 <= len(inputs) <= 64:
        raise ValueError('Provide 1..64 WAV files')
    sounds, common, total = {}, None, 0
    for filename in inputs:
        path = Path(filename)
        key = path.stem
        if not re.fullmatch(r'[A-Za-z0-9_:.-]{1,64}', key) or '..' in key or key in sounds:
            raise ValueError('WAV stems must be unique ASCII sound keys: ' + key)
        with wave.open(str(path), 'rb') as wav:
            channels, rate = wav.getnchannels(), wav.getframerate()
            count = wav.getnframes() * channels * 2
            if wav.getcomptype() != 'NONE' or wav.getsampwidth() != 2 or channels not in (1, 2) or not 8000 <= rate <= 48000:
                raise ValueError('Input must be PCM16 WAV, 1-2 channels, 8-48 kHz')
            if not 0 < count <= 8 * 1024 * 1024:
                raise ValueError('Input PCM must be 1..8 MiB per clip')
            raw = wav.readframes(wav.getnframes())
            if len(raw) != count:
                raise ValueError('Truncated WAV data')
        if codec == 'adpcm':
            sys.path.insert(0, str(Path(__file__).resolve().parent))   # audio_adpcm.py sits next to this file
            import audio_adpcm
            samples = array.array('h')
            samples.frombytes(raw)
            if sys.byteorder != 'little':
                samples.byteswap()
            fmt, _ = audio_adpcm.fmt_chunk(channels, rate)
            payload = audio_adpcm.encode(samples, channels)
        elif codec == 'pcm16':
            fmt = struct.pack('<HHIIHHH', 1, channels, rate, rate * channels * 2, channels * 2, 16, 0)
            payload = raw
        else:
            raise ValueError('Unknown codec')
        if common is not None and common != fmt:
            raise ValueError('All sounds in one namespace must share channels/rate/format')
        common = fmt
        total += len(payload)
        if total > 8 * 1024 * 1024:
            raise ValueError('Combined audio exceeds the 8 MiB namespace quota')
        sounds[key] = base64.b64encode(payload).decode('ascii')
    quote = lambda value: json.dumps(value, ensure_ascii=True)
    lines = ['-- Generated for MDL3.audio api 1; include this file with your mod.',
             'return {format=' + quote(base64.b64encode(common).decode('ascii')) + ',sounds={']
    lines += ['[' + quote(key) + ']=' + quote(value) + ',' for key, value in sorted(sounds.items())]
    lines += ['}}', '']
    return '\n'.join(lines), dict(codec=codec, clips=len(sounds), audio_bytes=total)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('wav', nargs='+')
    parser.add_argument('--codec', choices=['pcm16', 'adpcm'], default='pcm16')
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    source, result = build_assets(args.wav, args.codec)
    output = Path(args.out)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8', newline='\n') as file:
        file.write(source)
    print(json.dumps(dict(output=str(output.resolve()), **result)))


if __name__ == '__main__':
    main()
