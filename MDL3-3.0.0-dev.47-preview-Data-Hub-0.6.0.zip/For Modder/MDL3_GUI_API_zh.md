# MDL3 绘图接口 MDL3.gui（api 1，dev.41 起）

MDL3 自带的屏幕绘图层：矩形、描边、线、三角形、圆、文字（自动换行、对齐）、图片。只用游戏引擎自己的 Lua 绘图函数，**不用 FFI，不依赖 CSL**，普通 MOD 直接可用。

MDL3 帮你做三件事：

1. **参数先检查再交给引擎。** 引擎的绘图函数不检查参数类型，传错一个就会让游戏直接崩溃。MDL3.gui 收到错误参数时只报一个 Lua 错误（`MDL3.gui: ...`），记进 MDL 日志，游戏不会崩。
2. **管理画布的生命周期。** 换场景（进出任务、回船）时自动重建；MOD 在 MDL 里被关闭或重载时，它的画布自动清除。
3. **分辨率无关。** 默认坐标以 1080 高为基准，左上角为原点，y 向下；4K 下自动放大两倍。

## 取得接口

```lua
local function gui_api()
    local m = rawget(_G, 'MDL3'); if type(m) == 'table' and m.gui then return m.gui end
    local mdl = rawget(_G, 'MDL'); if type(mdl) == 'table' and mdl.gui then return mdl.gui end
end
local gui = gui_api()            -- nil：MDL3 早于 dev.41，或没有 MDL3
if gui and gui.api >= 1 then ... end
```

**文字需要 MDL3 的原生界面服务。** 文字使用游戏菜单当前的字体；证书没装好、原生服务没启动时，形状和图片照常显示，文字不显示，`canvas:status().font` 为 `false`。

## 示例

```lua
local gui, panel, bar
local mod = {name = 'My HUD'}
function mod.on_enable()
    gui = gui_api(); if not gui then return end
    panel = gui.canvas({layer = 40})
    local s = panel:screen()                         -- s.w：当前屏幕宽（基准单位，宽屏大于 1920）
    panel:begin()
    panel:rect(s.w - 360, 120, 320, 200, {10, 12, 16, 200})
    panel:frame(s.w - 360, 120, 320, 200, 2, '#FFD500')
    panel:text('标题 Title', s.w - 340, 136, {size = 24, color = {255, 213, 0}})
    panel:image('mods/me/my_hud/img/logo', s.w - 340, 180, 96, 96)
    panel:finish()
    bar = gui.canvas({layer = 60})
end
function mod.on_update(ctx, dt)
    if not bar then return end
    bar:begin()
    bar:rect(100, 900, 300 * hp_ratio(), 12, {150, 222, 120})   -- 每帧变化：原地更新，不重建
    bar:finish()
end
function mod.on_disable() if panel then panel:destroy(); bar:destroy() end end  -- 不写也会被 MDL3 清除
return mod
```

完整示例见 GUI Test 0.1.0（`gui_test.lua`）。

## 画布

`gui.canvas(opts)` 返回一个画布。

| 选项 | 默认 | 说明 |
|---|---|---|
| `layer` | 50 | 0–99，数字大的画在上面 |
| `units` | `'reference'` | `'reference'`：以 1080 高为基准；`'pixels'`：屏幕实际像素 |

每个 MOD 最多 16 个画布，每个画布最多 4000 个图元，超出部分会被丢弃并写入日志。

### 画布方法

- `begin()` … `finish()`：
  - 在两者之间画出完整的一帧，`finish()` 后从下一帧开始显示。
  - 内容不变时，再画一遍也不会重新提交给引擎。
  - 只想画一次的静态内容，画一次就行，画布会一直显示。
- `clear()`：清空画布。
- `show(false)` / `show(true)`：隐藏或显示画布。
- `destroy()`：销毁画布。
- `screen()`：返回 `{w, h, scale, pixel_w, pixel_h}`。`w`、`h` 是本画布单位下的屏幕大小。
- `measure(text, size)`：返回一行文字的宽度。
- `status()`：返回 `{items, font, problem, missing_image}`。

### 图元

坐标和尺寸用画布单位，原点在左上角，y 向下。

| 方法 | 说明 |
|---|---|
| `rect(x, y, w, h, color)` | 实心矩形 |
| `frame(x, y, w, h, thickness, color)` | 矩形描边（向内） |
| `line(x1, y1, x2, y2, width, color)` | 任意角度的线，宽度默认 2 |
| `triangle(x1, y1, x2, y2, x3, y3, color)` | 实心三角形 |
| `circle(x, y, r, color, {segments, ring})` | 实心圆。`ring = 粗细` 时画圆环；`segments` 取 12–96，默认按半径自动选 |
| `text(str, x, y, opts)` | 文字，返回整段的宽和高 |
| `image(name, x, y, w, h, {color})` | 图片。`color` 用来着色和设置透明度，默认白色、不透明 |

`text` 的选项：

| 选项 | 默认 | 说明 |
|---|---|---|
| `size` | 20 | 字号 |
| `color` | 白色 | 文字颜色 |
| `align` | `'left'` | `'left'`、`'center'`、`'right'`，分别表示 x 是左端、中心、右端 |
| `valign` | `'top'` | `'top'`、`'middle'`、`'bottom'` |
| `max_width` | 无 | 超过这个宽度就自动换行：中文按字换，英文按词换 |
| `line_height` | `size × 1.25` | 行高 |

文字中的 `\n` 会强制换行。

**颜色**有三种写法，各通道取值 0–255，`a` 省略时为 255（不透明）：

- `{r, g, b, a}`
- `{r = .., g = .., b = .., a = ..}`
- `'#RRGGBB'` 或 `'#RRGGBBAA'`

## 性能

- 内容完全不变时，几乎没有开销。
- 只改了矩形、三角形、线、圆的**位置、大小或颜色**时，MDL3 原地更新，不重建画布。血条、进度条、跟随移动的标记都属于这种情况。
- **上下顺序**：屏幕上所有 mod 画布的图元按层级依次排序，前约 790 个图元的先后顺序都是精确的，超出部分共用最上面一层，相互之间的上下关系不保证。
- **文字内容或位置、图片位置变了，或者图元的种类或数量变了**，这个画布会整个重建。比它层级高的画布也会跟着重建，以保证上下顺序正确。
  - 所以，经常变化的文字（计时、数字）应该放进**单独的高层画布**。
  - 也尽量不要每帧都改文字，比如数字每秒更新一次就够了。

## 图片

游戏运行时不能从 PNG 生成贴图，所以图片要先离线转换，再随 MOD 部署：

```powershell
pip install pillow
python gui_assets.py --mod mods/me/my_hud logo.png arrow.png --lua my_hud.lua --out build
```

- 会生成 `build/data/9ba626afa44a3aa3.patch_0`、`.gpu_resources` 和 `.stream` 三个文件，把 `data` 文件夹放进你的 MOD 包（manifest 写 `"Include": ["data"]`）。
- 加 `--lua` 时，MOD 的 Lua 文件会和图片打进同一个补丁。文件第一行必须是 `-- HD2-Addon: mods/...`。
- 代码里用的图片名是 `mods/me/my_hud/img/<文件名>`（不含扩展名）。`build/images.txt` 会列出所有图片名。
- 图片是未压缩的 RGBA 格式，并带全部 mip 级别：一张 256×256 约占 340 KB，512×512 约 1.3 MB。请保持图片小巧。
  - 边长最好是 2 的幂（64、128、256、512……）。
  - 最大 4096。
- **只有已经部署的 MOD 才能显示图片。** 在 MDL 库里实时启动、没有部署的 MOD，它的补丁没有被游戏加载，图片会被跳过：`status().missing_image` 会给出图片名，日志里会写 `image not loaded`。

## 不提供的东西

- **世界坐标转屏幕坐标**：需要相机投影，目前不提供。
- **3D 世界里的面板**：目前不提供。
- **鼠标点击**：目前不提供。
- **自定义字体**：目前不提供，正在研究。

MDL3.gui 也有意避开了几个已知会崩溃或无效的引擎调用，并替你处理了 `Gui.resolution()` 返回两个数字这个坑：

- `Gui.update_text`
- `Gui.bitmap_uv`
- 对没有贴图表的材质调用 `set_texture`
