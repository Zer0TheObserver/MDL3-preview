# MDL3 公共音频接口（api 2，dev.40 起；api 1 写法全部照常可用）

预览版与完整版均提供 `MDL3.audio`，普通 MOD 无需 unlock 或模块签名。由 MDL3 已签的 base 服务播放；MOD 不获得 FFI。当前配套宿主仍为已签 0.4.5，桥 DLL 不变。

本说明和转换工具 `audio_assets.py`（加上它用到的 `audio_adpcm.py`）都在 MDL3 包的 For Modder 文件夹里，两个 .py 放在同一个文件夹即可。

## 制作资源

准备 PCM16 WAV（单/双声道、8–48 kHz），同一命名空间的所有声音必须使用相同声道数、采样率和编码。离线生成 Lua 文件：

```powershell
python audio_assets.py kill.wav hit.wav --out sounds.lua
# 如需更小体积：
python audio_assets.py kill.wav hit.wav --codec adpcm --out sounds.lua
```

MS-ADPCM 编码器复用 BFV mdl3.4 的离线实现，512 samples/block。游戏运行时不解码 MP3/WAV，不打开声音文件，也不依赖 ffmpeg。
将生成的 sounds.lua 放入 MOD 脚本目录，通过 MOD 自身的 `require` 加载。

## 调用示例

```lua
local sounds = require('sounds')
local ns = 'mods/your_author/your_mod'
local audio
return {
    name = 'My sound mod',
    on_enable = function()
        audio = MDL3 and MDL3.audio
        if not audio or (audio.api or 0) < 1 then return end
        assert(audio.define_format(ns, sounds.format))
        assert(audio.pool(ns, {kill=4, hit=4, score=1}))
        for key, data in pairs(sounds.sounds) do assert(audio.upload(ns, key, data)) end
    end,
    on_update = function()
        -- 在你的事件处理代码中调用；资源未就绪/voice已满时返回false，不排队：
        -- audio.play(ns, 'kill', {role='kill', volume=75})
    end,
    on_disable = function() if audio then audio.release(ns) end end,
}
```

可以在服务 ready 前注册资源。上传分块、ACK 续传、owner/桥重连后的重传由 MDL3 负责；未被接受的播放请求不会自动补播。`play()` 的 true 表示根据最近状态预留并提交了本帧请求，最终是否播放由原生执行结果决定，不保证设备确实发声。

## 方法

| 方法 | 返回/用途 |
|---|---|
| `state()` | `wait/starting/ready/failed/unavailable`, reason；ready表示公共服务可接单，voice池可另外初始化 |
| `define_format(ns, fmt_b64)` | bool, reason；一个ns一个不可变格式，换格式先release |
| `pool(ns, roles)` | bool, reason；角色到voice数量的映射，改变池形状先release |
| `upload(ns, key, b64, opts)` | bool, reason；整段已编码音频数据。opts当前只接受nil或空表；同key内容不可变 |
| `ready(ns, key)` | bool, reason；原生侧校验完成，可提交播放 |
| `play(ns, key, opts)` | 成功返回**句柄**（正整数；api 1 的 `if play(...) then` 照常成立），否则 `false, reason`。opts 见下节 |
| `stop(ns, role?)` | bool, reason；停止该ns指定角色或全部声音，保留资源 |
| `status(ns)` | free、ready数量、keys_ready映射、failed、phase、pool、max_active、accepted、dropped等 |
| `release(ns)` | bool；异步销毁该ns的voice和缓冲，保留其它MOD及共享引擎 |


## api 2：句柄、暂停、循环、3D、混响（dev.40）

先判断 `audio.api >= 2` 再使用本节功能。

### 播放选项 `play(ns, key, opts)`

| 选项 | 说明 |
|---|---|
| `role`、`volume` | 同 api 1 |
| `loop` | `true` = 无限循环；数字 1..254 = 额外重复次数 |
| `paused` | `true` = 准备好但不出声，之后 `resume(h)` |
| `pitch` | 0.5..2，同时改变音高和速度 |
| `reverb` | 0..100，送入本 MOD 混响环境的量。3D 声音不写时按距离自动（越远越多）；非 3D 声音不写时为 0（干声） |
| `pos` | `{x, y, z}` 游戏世界坐标（米）——给了就是 3D 声音 |
| `unit`、`node` | 跟随单位（每帧读 `Unit.world_position(unit, node or 1)`）；单位失效后停在最后位置 |
| `spatial` | `{min = 1, max = 60, rolloff = 'inverse' 或 'linear', doppler = false}`：min 内不衰减，max 外无声 |

### 句柄方法

| 方法 | 说明 |
|---|---|
| `pause(h)` / `resume(h)` | 暂停（保留进度）/ 继续 |
| `halt(h)` | 只停这一个声音（`stop(ns, role)` 仍按组停） |
| `set(h, opts)` | 播放中修改 `volume`、`pitch`、`reverb`（数字或 `false`）、`pos`、`unit`/`node`、`spatial`；`loop = false` 让循环播完本轮后结束 |
| `info(h)` | `{state = 'playing'/'paused'/'ended', position, duration（秒）, loops, why, ns, key, role}`，比实际慢约 1 帧；结束的句柄保留最近 256 个 |
| `listener(v)` | 默认 `'camera'`：自动用 HD2 Data Hub 的相机位置和朝向（`HD2Data.aim()`）。也可传 `{pos = {x,y,z}, forward = {x,y,z}, up = {x,y,z}}` 自己指定；没有可用的听者时 3D 声音不做方向和距离处理 |
| `master(ns, volume)` | 本 MOD 所有声音的总音量 0..100（与每个声音的 volume 相乘） |

3D 只做方向（立体声左右）、距离衰减和可选的多普勒；不会被墙遮挡。3D 声源建议用单声道素材（立体声素材会先混成单声道再定位）。

### 混响 `environment(ns, preset, overrides)`

- `preset`：`'room'`、`'small_room'`、`'large_room'`、`'hall'`、`'corridor'`、`'cave'`、`'hangar'`、`'arena'`、`'sewer'`、`'forest'`、`'mountains'`、`'plain'`、`'city'`、`'underwater'`；`'off'` 或 `nil`（且无 overrides）关闭。
- `overrides`：在预设基础上修改的参数（`nil` 预设 + overrides = 在 `room` 的基础上自定义）：

| 参数 | 范围 | 含义 |
|---|---|---|
| `level` | -100..20 dB | 混响尾音音量 |
| `reflections` | -100..20 dB | 早期反射音量 |
| `decay` | 0.1..100 秒 | 衰减时间 |
| `room_size` | 1..100 | 房间大小 |
| `density` | 0..100 | 尾音密度 |
| `diffusion` | 0..15（整数） | 扩散度 |
| `reflections_delay` | 0..300 ms（整数） | 早期反射延迟 |
| `reverb_delay` | 0..85 ms（整数） | 尾音延迟 |
| `room` / `room_hf` | -100..0 dB | 整体 / 高频衰减 |
| `hf_reference` | 20..20000 Hz | 高频衰减的参考频率 |
| `low_eq_gain` / `low_eq_cutoff` / `high_eq_gain` / `high_eq_cutoff` | 0..12 / 0..9 / 0..8 / 0..14（整数） | 尾音低频、高频均衡 |

- `presets()` 返回每个预设换算后的上述参数表，可以拿来改。

> **⚠ 混响数量限制（请 MOD 作者务必注意）**
> 所有 MOD **合计**同一时间最多只能有 **3 种不同的混响设置**。参数完全相同的 MOD 共用同一个混响，不额外占用。
> 已有 3 种不同设置时，新的 `environment(...)` 会失败：调用当时返回 `true`（已排队），随后在日志里出现 `AUDIO_REQUEST_FAILED <ns> … reverb slots full`，该 MOD 保持原来的混响环境（或没有混响）。
> 建议：尽量直接用预设、不要随意微调参数；不需要混响时不要调用 `environment`；MOD 停用时调用 `release(ns)`（会同时释放它占用的混响）。

ns建议使用MOD资源路径，允许ASCII字母数字及 `_ / - . :`，不接受`..`；最长192字符。key最长64，role最长32。命名空间用于资源分组与配额，不是同一游戏Lua VM中恶意MOD之间的安全隔离。

## 配额与生命周期

- PCM16及标准7系数MS-ADPCM，1–2声道，8–48 kHz；ADPCM每块32–512样本。数据必须按格式的block align对齐，ADPCM预测器/步长头也会校验。
- 每ns最多512 MiB音频、64个key、12个voice；全局16个ns、512 MiB、256个key、64个voice（dev.24 起；之前为每ns 8 MiB、全局 32 MiB）。单个音效最多12000000个base64字符（约9 MiB）。音频 owner 内存配额 640 MB。
- dev.24：游戏侧保留的上传文本合计超过约 44M 字符（约 33 MiB 音频）后，已就绪音效的文本会被释放，只留指纹用于“同 key 同内容”的检查。音频服务重启（宿主重连等）后，这类音效 `audio.ready(ns, key)` 返回 `false, 'audio host restarted; upload this asset again'`，MOD 用同一 key、同一文本再 `upload` 一次即可；未被释放的音效照旧自动重传。
- 每次上传最多8192个base64字符（最多6144字节数据），每次step一个分块、最多32个播放请求、64个句柄操作和64个位置更新；有正在播放的 3D 声音时每帧一次 step，否则一次最多一个step在途。10 Hz空闲状态更新；没有音频需求时不初始化设备、不轮询音频设备。
- 初始化每0.25秒推进一项；单步失败最多40次，持续预算异常由前端等待重试，不按播放失败重放声音。初始化临时提高宿主时间片，TTL自动恢复；稳态不改性能参数。
- 设备调用可能慢于预算，watchdog不能中断C函数。此实现遵循已有BFV的分步/持久输出指针/settle经验；不声称有硬实时保证。
- MOD禁用时调用release。完整桥关闭时依次销毁source voices、mastering voice，再停止并释放engine；缓冲持有到voice销毁后。所有MOD共享同一owner与engine。
- owner重连会保留游戏侧源数据并重传，旧generation状态不会覆盖新资源。完整游戏关闭会释放游戏侧数据。

离线验证包括真LuaJIT/FFI的模拟COM、预算中断恢复、资源隔离、配额、PUC51队列/重连及真实桥的无令牌调用。实际游戏出声与切图体验需单独验收，不能用这些离线结果代替。
