"""MS-ADPCM encoder (the codec XAudio2 plays natively; 512 samples per block, the XAudio2 maximum).
Input: interleaved int16 PCM. Output: (fmt chunk bytes, data bytes). Used at build time only.
Adapted from BFV mdl3.4: clamp initial delta to the signed 16-bit header range
before encoding, so full-scale inputs use the same delta as the decoder."""
import struct
COEF=[(256,0),(512,-256),(0,0),(192,64),(240,0),(460,-208),(392,-232)]
ADAPT=[230,230,230,230,307,409,512,614,768,614,512,409,307,230,230,230]
SPB=512
def fmt_chunk(channels,rate):
    align=(SPB-2)*channels//2+7*channels
    avg=rate*align//SPB
    body=struct.pack('<HHIIHHH',2,channels,rate,avg,align,4,32)+struct.pack('<HH',SPB,7)
    for a,b in COEF: body+=struct.pack('<hh',a,b)
    return body,align
def _clamp16(v):return -32768 if v<-32768 else (32767 if v>32767 else v)
def _encode_channel(samples,pred,delta):
    c1,c2=COEF[pred];s2,s1=samples[0],samples[1];nib=[];err=0
    for x in samples[2:]:
        p=(s1*c1+s2*c2)>>8
        e=x-p
        n=int(e/delta) if e>=0 else -int(-e/delta)
        r=e-n*delta
        if r*2>delta and n<7:n+=1
        elif -r*2>delta and n>-8:n-=1
        n=max(-8,min(7,n))
        v=_clamp16(p+n*delta);err+=abs(x-v)
        s2,s1=s1,v
        delta=max(16,(ADAPT[n&15]*delta)>>8)
        nib.append(n&15)
    return nib,err
def _start_delta(samples):
    d=sum(abs(samples[i]-samples[i-1]) for i in range(2,min(len(samples),18)))//16
    return max(16,min(32767,d))
def encode(pcm,channels):
    """pcm: list/array of int16 interleaved"""
    frames=len(pcm)//channels
    out=bytearray()
    for start in range(0,frames,SPB):
        ch_samples=[]
        for c in range(channels):
            s=[pcm[(start+i)*channels+c] if start+i<frames else 0 for i in range(SPB)]
            ch_samples.append(s)
        preds=[];deltas=[];nibs=[]
        for s in ch_samples:
            d0=_start_delta(s)
            best=None
            for p in range(7):
                _,e=_encode_channel(s[:66],p,d0)
                if best is None or e<best[0]:best=(e,p)
            n,_=_encode_channel(s,best[1],d0)
            preds.append(best[1]);deltas.append(d0);nibs.append(n)
        hdr=bytes(preds)+b''.join(struct.pack('<h',min(32767,d)) for d in deltas)
        hdr+=b''.join(struct.pack('<h',s[1]) for s in ch_samples)+b''.join(struct.pack('<h',s[0]) for s in ch_samples)
        out+=hdr
        inter=[]
        for i in range(SPB-2):
            for c in range(channels):inter.append(nibs[c][i])
        for i in range(0,len(inter),2):out.append((inter[i]<<4)|inter[i+1])
    return bytes(out)
def wav(fmt,data):
    body=b'WAVE'+b'fmt '+struct.pack('<I',len(fmt))+fmt+b'data'+struct.pack('<I',len(data))+data
    return b'RIFF'+struct.pack('<I',len(body))+body
