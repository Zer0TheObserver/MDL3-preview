# HD2Data 字段参考（Hub 0.6.0，2026-11-06）

本文列出 MOD 通过 `HD2Data` 能拿到的**全部**函数和字段。用法示例和约定见 `API_zh.md`；本文只列字段。

通用规则：
- **nil 的含义**：所有字段都可能是 `nil`，表示这一帧读不到或数值不合理。调用方必须判空。
- **数值约定**：
  - 血量和数量都是游戏内整数；
  - 坐标单位是米；
  - 时间单位是秒（另有注明的除外）；
  - peer 是 16 位十六进制字符串；
  - 实体 id 和单位 id 是游戏内的 32 位整数，只在当前任务内有效。
- **“状态”列**：标“证明”的是静态逐字段证明过的（2026-10-27 重证）；标“推断”的是名称或含义靠推断；标“游戏代码”的会调用游戏自身函数（可以用 `set_option('getters', false)` 关掉；0.5 起只剩 `grenades_max` / `stims_max` 两项）。目前都还没有实机验证。

## 1. 函数一览

| 函数 | 返回 | 租约 / 开销 |
|---|---|---|
| `D.version` / `D.api` | Hub 版本字符串 / API 级别（1） | — |
| `D.state()` | `state, reason`。state 取值：`wait` / `linking` / `ready` / `failed` / `unsupported` / `stopped` | — |
| `D.ready()` | `state == 'ready'` | — |
| `D.build()` | §8 | — |
| `D.player()` | 本地玩家（§2），第二返回值是数据年龄（秒） | 租约 `player`，3 秒 |
| `D.player_ammo()` | 同上，另外附带弹药和上限（**只有一个返回值**） | 租约 `player` + `ammo`；0.5 起弹药为纯数据读取，只有 `grenades_max` / `stims_max` 仍调用游戏代码 |
| `D.players(detail)` | 小队数组（§3） | 租约 `players`，`detail=true` 时加 `players_detail` |
| `D.stratagems()` | 每个玩家的战略配备（§5） | 租约 `stratagems` |
| `D.stratagem_catalog(t)` | 战略配备目录（§6）：`t=nil` 返回整张表（按 type 索引）；`t` 为数字时按 type 查（找不到再按 id 查），为字符串时按内部名查 | 只读一次，之后缓存；第一次调用返回 `nil` |
| `D.aim()` | 本地瞄准（§7） | 租约 `aim` |
| `D.buffs()` | 增强剂与状态效果（§15，0.5 起） | 租约 `buffs` |
| `D.lobby()` / `D.lobby_search()` | 当前房间 / 大厅浏览结果（§16，0.5 起） | 租约 `lobby` / `lobby_search` |
| `D.backpacks()` | 每个玩家背着的背包状态（§17，0.6 起） | 租约 `backpacks` |
| `D.strikes()` | 正在进行的打击（§12，0.3 起） | 租约 `strikes` |
| `D.enemy_pool(refresh)` | 当前星球每个任务的预测敌人池（§14，0.4 起）；`refresh=true` 重新计算 | 请求一次算一次，之后缓存；第一次调用返回 `nil` |
| `D.strike_catalog(key)` | 打击目录（§13，0.3 起）：`key=nil` 返回整张表（按设置哈希索引），否则按哈希或名称查 | 只读一次，之后缓存；第一次调用返回 `nil` |
| `D.mission()` | `{in_mission, epoch, now}`（§8） | — |
| `D.on(name, cb, opts)` | 订阅对象（§9） | 只计算被订阅的事件 |
| `D.events()` | 16 个事件名的数组 | — |
| `D.event_status()` | 按事件列出状态（§8） | 约每秒刷新一次 |
| `D.subscriptions()` | 全部订阅的说明（§9） | — |
| `D.set_option('getters', bool)` | 返回 `true` / `false`；目前只有这一个选项 | — |
| `D.diagnostics()` | §8 | — |

租约：调用以后的 3 秒内，Hub 每帧更新该项数据；不再调用就停止读取。调用方拿到的数据都晚一帧，**第一次调用当帧返回 `nil`**。没有任何订阅、也没有任何租约时，Hub 只以 4 Hz 跟踪任务状态。

## 2. 本地玩家 `D.player()` / `D.player_ammo()`

不在任务中，或者化身不存在时，返回 `nil`。

| 字段 | 类型 | 说明 | 状态 |
|---|---|---|---|
| `peer` | string | 64 位 peer（十六进制） | 证明 |
| `slot` | int | 玩家槽 0..3 | 证明 |
| `is_local` | bool | 恒为 `true` | 证明 |
| `name` | string | 玩家名（最多 0x80 字节，UTF-8） | 证明 |
| `entity` | int | 化身实体 id | 证明 |
| `player_entity` | int | 玩家（不是化身）实体 id | 证明 |
| `health` / `health_max` | int | 当前和最大血量；当前值已截断到 ≥0 且 ≤max | 证明 |
| `health_frac` | number | `health / health_max` | — |
| `life` | string | `'alive'` / `'downed'` / `'dead'` | 证明 |
| `alive` | bool | `life ~= 'dead'`（倒地也算 `true`） | 证明 |
| `unit` | int | 化身的单位 id | 证明 |
| `position` | Position | 化身根节点位置（§10） | 链已证明；平移行为推断 |
| `weapons` | table | `{primary=id, secondary=id, support=id}`，值是武器实体 id；空槽为 `nil` | 偏移证明，槽名推断 |
| `weapon` | table | 手持物，见下表 | 见下表 |
| `loadout` | table | 0.3 起：`primary` / `secondary` / `support` 各一项 `{slot, entity, held, rounds, capacity, mags, mags_max}`；空槽为 `nil`；弹药数只有 `player_ammo()` 才会填，收起的武器同样有 | 实体 id 证明；弹药为游戏代码（读取函数只按武器实体查，不区分是否手持），收起武器的实测待确认 |
| `grenades` / `stims` | int | 当前手雷数和针剂数 | 证明 |
| `grenades_max` / `stims_max` | int | 上限，**只有 `player_ammo()` 才会填** | 游戏代码 |
| `backpack` | table | 0.4 起（随 `player_ammo()`）：背着的背包 `{entity, count, max}`，`count` / `max` 是背包里的弹药或补给数量和上限（弹药背包、补给背包、背包供弹武器的备弹）；没背背包时为 `nil` | 证明（HUD 读的就是这两个数） |

`weapon`（手持物）：

| 字段 | 说明 | 状态 |
|---|---|---|
| `category` | 游戏的手持类别 1..6（已照搬游戏 0x83DEF0 的覆盖分支） | 证明 |
| `slot` | `'primary'` / `'secondary'` / `'support'` / `'held_item'` / `'slot_0c'` | 类别到偏移的对应已证明，名称推断；`slot_0c` 用途未识别 |
| `entity` | 手持物实体 id | 证明 |
| `rounds` / `capacity` | 当前弹匣弹数和弹匣容量（只有 `player_ammo()` 才会填） | 0.5 起纯数据：读游戏的同步数据（和游戏自己给队友用的读法相同），并按游戏规则补上膛内一发 |
| `mags` / `mags_max` | 备用弹匣数和上限（同上）；背包供弹武器含背包里的量，另有 `mags_backpack` | 同上 |
| `chambered` / `shared_pool` | 0.5 起：武器带膛内一发的规则（弹匣式和逐发装填式都按游戏规则处理）/ 两种弹种共用一个弹池 | 同上 |

**0.5 与 0.4 的读数差异：** 0.4 调用游戏自己的读数函数，0.5 改为直接读同步数据，以下三处修正 0.5 不再做：连接型弹药的 +1、无限弹药时的特殊值、空膛时报 0。所以无限弹药状态下 `rounds` 是同步里的真实数字，连接型弹药武器 `rounds` 为 `nil`。

`loadout` 每一项和手持的 `weapon`，0.4 起再加以下字段（只有本地玩家，**只在 `player_ammo()` 时提供**；这部分是纯数据读取，不调用游戏代码）：

| 字段 | 说明 | 状态 |
|---|---|---|
| `ammo_type` | `'magazine'`（弹匣）/ `'heat'`（热量武器，如激光类）/ `'rounds'`（逐发装填）；其他武器为 `nil` | 证明（游戏读弹药的函数就按这个分支） |
| `heat` | 仅热量武器：`{value, max, frac, overheat, warn, unlock, temperature, sinks, locked, charge, charging}`。`value` 当前热量（开火时上升），`frac = value/max`，`overheat` / `warn` / `unlock` 为过热、警告、解锁阈值，`temperature` 是 HUD 用的平滑值，`sinks` 剩余散热片，`locked` 过热锁定中，`charge` / `charging` 蓄力值 / 是否在蓄力 | 证明；冷却速度未找到（可按 `value` 的变化自己算） |
| `reload` | `{active, elapsed, speed, phase}`：是否正在装弹、已经装了几秒、装弹速度系数、游戏内部阶段位 | 证明；**没有 0..1 进度**：装弹总时长写在每把武器各自的代码里，不在数据表中 |
| `charge` | 蓄力武器的蓄力值 | 证明 |
| `backpack_fed` | 这把武器从背包供弹（如无后坐力炮） | 证明 |

**热量武器的弹药数要换个理解：** 对 `ammo_type == 'heat'` 的武器，`rounds` 其实是当前热量（取整，开火时上升），`mags` 是散热片数加背包里的量。用 `heat` 字段更直观。背包供弹的武器，`mags` 已经包含背包里的弹药。

## 3. 小队 `D.players(detail)`

返回数组，每个玩家一项。基础字段与 §2 相同：`peer, slot, is_local, name, entity, player_entity, health, health_max, health_frac, life, alive, unit, position`。

`detail=true` 时再加：`weapons`、`weapon`（只有 `category / slot / entity`）、`loadout`（`slot / entity / held`）、`grenades`、`stims`。

0.5 起，`detail=true` 时小队成员的 `loadout` 每把武器和手持 `weapon` 也带弹药：`rounds, capacity, mags, mags_max, ammo_type`，热量武器另有 `heat = {value, max, locked, sinks, sinks_max}`。数据来自游戏的网络同步：射击每发同步、热量每帧同步、备用弹匣在换弹或补给时同步，所以会比队友本机稍慢。连接型弹药和载具武器为 `nil`。队友背包的剩余量只有在能对上队友的背包时才给。

## 4. 句柄类型（事件和数据里的对象）

**Entity**（事件里的 `e.entity`）

| 字段 / 方法 | 说明 |
|---|---|
| `id` | 实体 id |
| `type` | 实体类型哈希（16 位十六进制） |
| `semantic_id` | 语义 id，例如 `enemy/v1/automatons/conscript_tier_3`；目录里查不到时为 `entity/v1/unresolved/<type>` |
| `name` / `display_name` | 内部名 / 显示名（目录里有才有） |
| `faction` | `helldivers` / `automatons` / `terminids` / `illuminate` / `super_earth` |
| `kind` | `enemy` / `weapon` / `stratagem` / `structure` / `throwable` |
| `enemy` | bool：是否计为击杀目标 |
| `avatar` | bool：是否为玩家化身 |
| `unit` / `network_id` | 单位 id / 网络 id（可能为 `nil`） |
| `:is_valid()` | 该实体仍在本任务的生命值表里时为 `true` |
| `:is_enemy()` / `:is_player_avatar()` | 同 `enemy` / `avatar` |
| `:max_health()` | 最大血量 |
| `:position()` | 事件发生时的位置（Position）；只有 spawned / damaged 事件带 |
| `:is(x, ...)` | `semantic_id` 是否等于任一参数；也可以传 `{[sid]=true}` 这样的集合 |
| `:describe()` | 以上字段的普通表，另加 `mission` 和 `valid` |

目录共收录 355 种实体：敌人 138、武器 126、战略配备 70、建筑 39、投掷物 23。

**Strike**（`D.strikes()` 的每一项和 `strike_started` 事件）：见 §12；方法 `:contains(pos, margin)`、`:describe()`。

**Player**（事件里的 `killer` / `attacker` / `player` / `caller`）：字段 `peer, slot, is_local`；方法 `:is_local_player()`、`:describe()`。

## 5. 战略配备 `D.stratagems()`

数组，每个玩家一项：`peer, slot, is_local, entity, name, stratagems`。`stratagems` 是数组，每项字段如下：

| 字段 | 说明 |
|---|---|
| `type` / `name` / `id` | 战略配备类型号（1..153）/ 内部名 / 游戏 id |
| `granted` / `loadout` | 是任务中获得的，还是装备栏自带的（两者互斥） |
| `unlimited` / `uses` | 是否不限次 / 剩余次数（共享次数的会取共享池的值） |
| `uses_base` | 描述符里的基础次数 |
| `shared` | 是否和全队共享冷却 |
| `cooldown_left` | 冷却剩余秒数（增援 127 号用全局增援冷却） |
| `ready` | 冷却已结束且还有次数 |
| `cooldown_base` / `call_in_base` | 描述符里的冷却和呼叫时间（秒） |
| `last_cooldown` / `last_call_in` | 上一次实际的冷却和呼叫时间（秒，用过才有） |

## 6. 战略配备目录 `D.stratagem_catalog()`

每项字段：`type, name, id, uses, unlimited, call_in, cooldown, shared, category, selectable, code`，0.3 起另有 `area`（该战备对应的打击目录项数组，见 §13）。`code` 是指令序列，例如 `{'up','right','down',...}`；遇到未知方向时保留原始数字。

## 7. 瞄准 `D.aim()`（只有本地玩家）

| 字段 | 说明 |
|---|---|
| `avatar` | 化身实体 id |
| `aiming` | 是否在举镜瞄准（标志位 bit18，且 bit44 未屏蔽） |
| `frozen` | 输入是否被冻结 |
| `camera_point` | 摄像机射线命中点 |
| `camera_distance` / `camera_hit` | 摄像机到命中点的距离 / 是否真的命中（距离 < 999.5） |
| `weapon` | 当前武器实体 id |
| `impact` | 武器的真实落点 |
| `target` | 带摆动的瞄准目标点 |
| `distance` | 摄像机到 `impact` 的距离 |
| `camera` | 摄像机位置 |
| `forward` | 摄像机朝向（普通表 `{x,y,z}`，不是 Position） |
| `screen` | 准星屏幕坐标 `{x, y, depth}`（像素） |

## 8. 状态与诊断

- `D.build()`：`{build, key, status, reason, hub}`。`status` 为 `matched`、`unsupported` 等；`hub` 是 Hub 版本。
- `D.mission()`：
  - `in_mission`（bool）；
  - `epoch`：任务序号，每进出一次任务加一，实体句柄按它判断是否失效；
  - `now`：Hub 时钟（秒）。
- `D.event_status()`：`{[事件名] = {status, reason, subscribers}}`。`status` 取值：`idle`（无人订阅）/ `active` / `retry` / `unavailable`（连续失败 30 次）。
- `D.diagnostics()`：`{state, why, hub, describe, want, frames, restarts, step_failures}`。其中：
  - `hub` = `{build, reason, reads, read_failures, getter_calls, getter_failures}`；
  - `describe` = `{phase, build, key, status, reason, version}`。

## 9. 事件 `D.on(name, cb, opts)`

`opts`：
- `owner`：字符串，建议用 MOD 路径；
- `id`：同一 owner 下 id 相同时只替换回调；
- `priority`：越大越先调用。

订阅对象的方法：`:disable()`、`:enable()`、`:unsubscribe()`、`:active()`、`:describe()`。`describe()` 返回 `{id, event, owner, state, reason, calls, failures}`。回调连续出错 25 次会被停用。

**每个事件都带的字段**：
- `event`：事件名；
- `time`：Hub 时钟，秒；
- `frame`：Hub 帧号；
- `mission`：任务序号；
- `cause = {source='native'}`。

| 事件 | 字段 | 状态 |
|---|---|---|
| `mission_started` | `mission, host（bool）, mode, game_state, first_observation` | 状态值证明；`host` 和 `mode` 推断 |
| `mission_ended` | `mission, duration（秒）, game_state` | 证明 |
| `entity_spawned` | `entity`（带位置）, `entity_id, type, semantic_id, name, display_name, enemy, faction, kind, avatar, unit_id, network_id` | 证明 |
| `entity_damaged` | 上一行全部字段，再加 `damage, health（≥0）, max_health, attacker, local_attacker, attacker_peer, downed`；0.4 起再加 `attacker_entity, attacker_type, attacker_name, attacker_semantic_id` | 证明；倒地时游戏存 -1，这里截断为 0 |
| `entity_died` | spawned 的全部字段，再加 `killer, local_killer, killer_peer, position, max_health, observed, corpse_id`。`observed` 为 `'dead_state'` 或 `'corpse'`。0.4 起再加 `killer_entity, killer_type, killer_name, killer_semantic_id, killer_self, killer_from_down`，以及 `downed_by_entity / _type / _name / _semantic_id`（把它打倒地的那一击） | 证明 |
| `entity_killed` | 同 `entity_died`；只有存在得分的 peer 时才触发 | 证明 |
| `player_fired` | `player, local_player=true, shots（本次新增）, total, sources, unattributed` | 证明 |
| `player_hit` | 同上，计数字段为 `hits` | 证明 |
| `player_damage_dealt` | 同上，计数字段为 `damage` | 证明 |
| `player_kill_credited` | 同上，计数字段为 `kills` | 证明 |
| `explosion` | `name, position, observed='queue', source_id, source_type, source_name, owner_id, owner_type, owner_name, creditor_peer, player, local_player` | 证明 |
| `bughole_destroyed` | `hole, name, bile_titan, entity_id, type, unit_id, level, position, owned` | 证明 |
| `stratagem_called` | `stratagem, name, id, shared, entity_id, target, beacon, thrower_position, owned, local_player, caller, caller_source, caller_distance` | 自己的呼叫精确；别人的取离投掷点最近的玩家（`caller_source='nearest'`） |
| `stratagem_used` | `stratagem, name, id, shared, player, peer, local_player, uses_left, caller_exact` | 非共享的精确；共享的只有在次数下降时才能确定是谁 |
| `strike_started` | 一条完整的打击（Strike 句柄，字段见 §12） | 0.3 起 |
| `strike_ended` | `id, kind, name, settings, source, stratagem, duration` | 0.3 起；读取失败时不会误报 |

补充说明：
- `player_*` 四个事件的 `sources` 是数组，按来源类型列出 `{type, name, <计数字段>=本次增量}`，从大到小排序。`unattributed` 是没有来源归属的部分。
- 地图的 `game_state` 取值：`None, Splash, TitleScreen, Ship, Mission, PrepareShip, PrepareMission, PrepareTestLevel, PrepareDebugMission`。
- `mode` 取值：`None, Mission, Horde, Opportunity, Tutorial, Blitz, Gloom, Infiltration`。
- `hole` 取值：`base, bile_titan, boomer, hiveguard, hunter, prowler, scavenger, scavenger_captive, shrieker, spitter, stalker, warrior, warrior_captive, warrior_ceiling, warrior_tutorial`。
- 增援（127 号）在任务内按全队计费，不会产生 `stratagem_used`。
- 0.4 的 `*_entity` 来自血量记录里"最后一击的归属实体"：子弹是开枪的人（不是子弹本身），爆炸是发出爆炸请求的实体，脚本伤害是受害者自己（此时 `killer_self = true`），环境伤害没有（字段为 `nil`）。倒地后流血而死时，按游戏的计分规则改记为把它打倒地的实体，并标 `killer_from_down = true`。`*_type` 是那个实体的类型哈希，`*_name` / `*_semantic_id` 来自实体目录；击杀者在受害者死前就消失时，类型取最近一次读到的值。
- 伤害类型和元素（火、电、毒……）**不提供**：游戏在同一帧内把伤害请求排队又处理掉，只读方式看不到大部分请求，给出的数据会时有时无。

## 10. Position

字段 `x, y, z`。方法：
- `:distance(other)`：`other` 可以是任何带 x/y/z 的表；
- `:unpack()`：返回 `x, y, z`；
- `:copy()`：返回普通表；
- `:vector3()`：返回 Stingray 的 `Vector3`，引擎不可用时为 `nil`。

`tostring(p)` 输出形如 `(x, y, z)`，保留两位小数。

## 11. 完整示例

一个最小的脚本 addon：
- 屏幕上显示自己的血量、手持武器的弹药和瞄准距离；
- 统计本局自己的击杀数；
- 自己呼叫战略配备时打印名字。

```lua
-- mods/example/hub_demo（游戏 VM，PUC Lua 5.1）
local OWNER = 'mods/example/hub_demo'
local kills, subscribed = 0, false
local subs = {}                         -- D.on 返回的订阅对象，退出时取消

-- 每次用时再取，不在顶层缓存（加载顺序不固定，Hub 被关掉后这个全局会消失）
local function hub()
    local D = rawget(_G, 'HD2Data')
    if D and D.ready() then return D end
    return nil
end

local function subscribe(D)
    -- 同一个 owner 和 id 重复调用只会替换回调，可以放心重复执行
    subs.kills = D.on('entity_killed', function(e)
        if e.local_killer and e.enemy then kills = kills + 1 end
    end, {owner = OWNER, id = 'kills'})
    subs.reset = D.on('mission_started', function(e) kills = 0 end, {owner = OWNER, id = 'reset'})
    subs.calls = D.on('stratagem_called', function(e)
        if e.local_player then print('[hub_demo] 呼叫: ' .. tostring(e.name)) end
    end, {owner = OWNER, id = 'calls'})
    subscribed = true
end

local function hud_text(D)
    -- 每帧都调用，租约才会续上；第一帧返回 nil
    local me = D.player_ammo()          -- 只要血量的话用 D.player()，不会执行游戏代码
    if not me or not me.health then return nil end
    local text = string.format('HP %d/%d (%s)  击杀 %d', me.health, me.health_max, me.life, kills)
    local w = me.weapon
    if w and w.rounds then
        text = text .. string.format('  弹药 %d/%d  弹匣 %s', w.rounds, w.capacity or 0, tostring(w.mags))
    end
    local aim = D.aim()
    if aim and aim.aiming and aim.distance then
        text = text .. string.format('  距离 %.1f m', aim.distance)
    end
    return text
end

local previous_update = update
update = function(dt, ...)
    local D = hub()
    if D then
        if not subscribed then subscribe(D) end
        local text = hud_text(D)
        -- 在这里用 text 画到界面上（略）
    else
        subscribed = false              -- Hub 重启或被关掉后重新订阅
    end
    if previous_update then return previous_update(dt, ...) end
end

local previous_shutdown = shutdown
shutdown = function(...)
    for _, sub in pairs(subs) do sub:unsubscribe() end
    subs = {}
    if previous_shutdown then return previous_shutdown(...) end
end
```

要点：
- 所有字段先判空再用，`player_ammo()`、`aim()` 第一次调用的那一帧都是 `nil`。
- 想要持续更新就每帧调用（3 秒租约）；不调用时 Hub 会自动停止读取，不产生开销。
- 回调里只做轻量的事，连续出错 25 次会被停用。
- 不需要弹药数时用 `D.player()`，它完全不执行游戏代码。

## 12. 打击范围 `D.strikes()`（0.3 起）

租约 `strikes`，3 秒。返回数组，每项是一次正在进行的打击，没有打击时为空数组。包括玩家的轨道齐射、飞鹰、轨道激光 / 电磁炮，以及使用同一机制的环境危害和敌方轰炸。每项都是 **Strike** 句柄。

**共有字段**

| 字段 | 说明 | 状态 |
|---|---|---|
| `kind` | `'barrage'`（轨道齐射 / 危害 / 敌方轰炸）/ `'eagle'` / `'orbital'`（激光、电磁炮） | 证明 |
| `id` | 打击实体 id，打击存续期间不变 | 证明 |
| `settings` | 设置哈希（16 位十六进制，跨版本不变） | 证明 |
| `name` | 名称，例如 `'Orbital 380MM HE Barrage'`、`'Meteor Shower'`；未收录的为 `nil` | 名称表（RawData） |
| `source` | `'stratagem'` / `'hazard'` / `'enemy'` / `'unknown'` | 战备关联证明；危害 / 敌方为名称表标签 |
| `stratagem` | 对应的战备类型号 | 证明 |
| `caller` / `caller_source` | 呼叫者（Player 句柄）。飞鹰为 `'thrower'`（精确）；轨道齐射取 30 秒内、150 米内最近的 `stratagem_called` 信标，沿用它的 `caller_source` | 飞鹰证明；齐射为匹配 |
| `owned` | 本机拥有该打击 | 证明 |
| `upgraded` | 用的是带舰船升级的实例设置（而不是静态设置） | 证明 |
| `started` | 首次看到它时的 Hub 时钟（秒） | — |
| `shape` | `'square'` / `'walking'` / `'strafe'` / `'pattern'` / `'point'` / `'beam'` / `'rail'` | 见各类 |
| `envelope` | 外包络：`{shape='circle', center, radius}` 或 `{shape='capsule', a, b, radius}`，覆盖可能落点加爆炸半径 | 推导 |
| `blast` | `{inner, outer, stagger}`，弹种爆炸半径（米） | 证明 |
| `danger` | 游戏给 HUD / AI 用的危险半径：`max(8, 区域, 爆炸外径)` | 游戏代码同式 |
| `confidence` | 每项数据的来源：`code` / `data` / `replica` / `estimate` / `derived` | — |
| `:contains(pos, margin)` | 只看 xy，点是否在包络内；`margin` 可选（米） | — |
| `:describe()` | 普通表 | — |

**轨道齐射（`kind='barrage'`，shape 为 `square` 或 `walking`）**

| 字段 | 说明 |
|---|---|
| `center` / `origin` | 当前落点中心 / 呼叫点（Position） |
| `half` | 落点正方形半边长（米），已乘舰船升级的范围系数 `area_modifier` |
| `drift` / `reset_half` | 每发之间中心的漂移范围 `{min, max}` / 每轮开始时中心的随机半径 |
| `shells` | `{per_salvo, salvos, salvo, salvos_left, left_in_salvo, fired, total, remaining, next_in, interval, salvo_interval}` |
| `next` | 接下来最多 64 发的预测：`{t, x, y, salvo, shot, projectile}`，`t` 为距今秒数；还没发射的保持在 `t=0` |
| `in_flight` | 已发射未落地：`{x, y, lands_in, projectile}`（落地时间按发射高度 / 弹速估算） |
| `time_left` | 整轮剩余秒数（超过 64 发的部分按平均间隔估算） |
| `velocity` / `heading` / `end` | 仅移动弹幕：速度 `{x, y}`、方向（弧度）、预计终点 |

`next` 复现了游戏的随机数和逐帧计时，在模拟器里和游戏原代码逐发一致（≤ 0.016 m）。只算 xy；环境危害避让玩家的偏移不计算；帧率变化时 `t` 会有少量偏差。

**飞鹰（`kind='eagle'`）**

| 字段 | 说明 |
|---|---|
| `target` / `approach` | 攻击点 / 进场起点（Position） |
| `heading` | 进场方向（弧度） |
| `position` / `aim` | 飞机当前位置 / 当前瞄准点 |
| `state` / `progress` | 游戏内部状态值 / 进度 |
| `payload` | `'strafe'`、`'double_strafe'`、`'missile'`、`'rocket'`、`'airstrike'`、`'carpet'` |
| `interval` / `duration` | 投弹间隔 / 开火时长（秒） |
| `thrower` | 投掷信标的化身实体 id |
| `from` / `to` / `width` | 仅 `shape='strafe'`：扫射线段和宽度 |
| `points` / `pattern` | 仅 `shape='pattern'`（空袭 / 集束）：每颗炸弹的落点（Position 数组）和图案编号 |

其他飞鹰（500KG、导弹等）为 `shape='point'`，以攻击点为圆心。

**轨道激光 / 电磁炮（`kind='orbital'`）**

| 字段 | 说明 |
|---|---|
| `position` / `origin` | 光束当前位置 / 起点 |
| `time_left` / `start_in` | 剩余时间 / 开始前延迟（秒） |
| `speed` / `retarget_radius` | 光束移动速度 / 重新索敌半径 |
| `damage_radius` / `zone` | 伤害区半径 / 形状（`'sphere'`、`'box'`、`'capsule'`） |
| `eta` | 仅电磁炮：命中倒计时 |

## 13. 打击目录 `D.strike_catalog(key)`（0.3 起）

本版本全部打击设置（危害也包括在内），按设置哈希索引。`key` 为 `nil` 时返回整张表；为哈希或名称时返回该项。只取一次，之后缓存，进新任务时刷新；第一次调用返回 `nil`。

每项共有：`settings, component（'bombardment' / 'eagle' / 'orbital'）, name, source, stratagems（关联的战备类型号数组）, shape, blast`。另外：

- **bombardment**：`initial_delay, shells_per_salvo, salvos, shell_interval, shell_jitter, salvo_interval, salvo_jitter, area, drift_min, drift_max, reset_half, fire_height, walk_speed, start_delay, walk_angle, types, danger`。
- **eagle**：`payload, pattern, projectile, duration, interval, strafe_length, danger`，空袭类另有 `points`（相对坐标 `{沿航线, 向左}`）。
- **orbital**：`kind（'beam' / 'rail'）, duration, speed, retarget_radius, zone, damage_radius, projectile`。

`D.stratagem_catalog(t).area` 是该战备对应的目录项数组。

## 14. 敌人池预测 `D.enemy_pool(refresh)`（0.4 起）

在飞船上（或任务中）预测**当前星球上每个可选任务**进图后会加载哪些敌人（含变种）。做法是照搬游戏任务包加载时的名单筛选，全部是数据读取加计算，不调用游戏函数。

- 不是租约：调用一次就请求计算一次，结果缓存起来；第一次调用返回 `nil`，一两帧后有值。第二个返回值是结果的年龄（秒）。
- `D.enemy_pool(true)` 丢弃缓存重新计算（例如按 F5 时）。进出任务时缓存也会清掉。
- 失败时返回 `{error = 原因}`，5 秒后再调用会重新请求。单个任务读不出来时，该任务项为 `{op, entry, error}`，其他任务照常给出。
- 飞船换到别的星球时，缓存自动丢弃。
- 计算量：几毫秒，不要每帧调用。

结果：`{planet, missions, notes}`。`missions` 每项：

| 字段 | 说明 |
|---|---|
| `op` / `entry` / `mission_id` | 作战行下标 / 任务条目下标 / 任务 id |
| `template` / `seed` / `category` | 任务模板 / 种子 / 类别 |
| `difficulty` / `tech` | 难度 / 科技等级（敌人权重和变种按 tech 算，不是按难度） |
| `race` | `'bugs'` / `'bots'` / `'illuminate'`，未知时为数字 |
| `region` | 区域，没有为 -1 |
| `tags` | 最终的任务 tag 集合（8 位十六进制） |
| `terrain_sensitive` | 结果可能受地形（生物群系）影响 |
| `enemies` | 数组，按名单顺序：`{entity, name, semantic_id, display_name, forced, variant_of, terrain}` |

`enemies` 每项：`entity` 是最终实体类型哈希（16 位十六进制，可交给 Entity 目录查）；`forced` 表示因任务目标强制加载；`variant_of` 表示它由哪个原始实体换成了变种；`terrain` 表示这一项可能因地形而变化。

限制（都已写在 `notes` 里）：
- **地形 tag 算不出来**：它在进图生成关卡时才产生，飞船上不存在。受它影响的项标了 `terrain`，不保证准确。
- 只预测"会被加载"的敌人，不代表一定刷出来，也不含数量。
- 每局都加载的中立名单和少量固定包不在结果里。
- 列出的是该星球所有作战里的任务，其中可能有当前还没开放的。
- 全部为静态分析结论，在模拟内存上与独立参考实现逐项一致，**未经实机对照**。

## 15. 增强剂与状态效果 `D.buffs()`（0.5 起）

租约 `buffs`，3 秒。返回 `{team, players}`；纯数据读取，不调用游戏代码。

- `team`：全队当前生效的增强剂数组 `{{id, name}, ...}`（空槽位和"未设置"的槽位跳过）。
- `players`：每个玩家一项 `{peer, slot, is_local, name, booster, effects}`：
  - `booster`：`{id, name, stratagem}`，没有带增强剂为 `nil`。`name` 是游戏内部名（如 `Vitality`、`Stamina`、`MuscleEnhancement`、`UAVRecon`、`FreeEAT`），不是界面翻译文字；`stratagem` 是该增强剂附带的战备类型号（如有）。队友的也会同步。
  - `effects`：身上的状态效果数组，每项 `{type, label, slot, stacks, source, time_left, duration, elapsed, intensity}`：
    - `type` 是游戏的状态类型号（0–73）；`label` 只对能确认的 17 个类型给出（`bleed` / `fire` / `acid` / `toxic_gas` / `electric` / `radiation` / `thornbush` / `barbwire` / `pure`），其余为 `nil`。
    - `source = 'local'`：本机有计时数据，`time_left` / `duration` / `elapsed` / `intensity` 有值；`source = 'mask'`：只知道"有这个效果"和层数（队友身上的效果通常是这种）。

| 项 | 状态 |
|---|---|
| 增强剂（每人 / 全队） | 证明；队友同步已证明 |
| 增强剂内部名 | 证明（与游戏枚举逐项对应） |
| 状态效果的类型、层数 | 证明；队友同步已证明 |
| 队友身上效果的剩余时间 | 推断读不到（只在本机生效的效果有计时） |
| 状态类型名 | 17 个证明（来自 HUD 代码），其余无名字表 |
| 打针后的持续回血、护甲被动 | 未找到对应的状态效果 |

## 16. 大厅 `D.lobby()` / `D.lobby_search()`（0.5 起）

两个都是租约（3 秒），只在 PlayFab 大厅模式下有数据；不在大厅时返回 `{error = 原因}`。纯数据读取。

**隐私**：
- 玩家账号 id 一律换成**不透明编号** `'L1'`、`'L2'`……：按第一次见到的顺序编号，同一局内同一个人的编号不变；每次进出任务 / 换会话都从 `'L1'` 重新编号。编号只是计数，无法反推出账号。
- 加入用的连接串、房主国家、近似地理坐标、一个含义不明的房主文本字段**永远不输出**。

`D.lobby()`（你当前所在的房间）：`{host_is_local, members, props, raw, mission}`
- `members`：最多 4 项 `{id（不透明）, is_local, is_host}`。名字请用 `D.players()` 按 `is_local` / 顺序对照（大厅数据本身不带名字）。
- `props`：

| 字段 | 含义 | 状态 |
|---|---|---|
| `version` | 内容版本哈希（版本一致才能加入） | 证明 |
| `host` | 房主（不透明标识） | 证明 |
| `players` | 当前人数 | 证明 |
| `phase` | `'ship'` / `'mission'` | 推断 |
| `deployed` | 任务已部署、可中途加入 | 推断 |
| `sos` | SOS 信标开着 | 推断 |
| `time_left_pct` | 任务剩余时间百分比 | 推断 |
| `war` | 战争 / 赛季编号 | 推断 |
| `planet` | 星球编号 | 推断 |
| `onboarding` | 房主仍在新手流程 | 推断 |
| `op_progress_pct` | 作战进度百分比 | 推断 |
| `mission_type` | 任务类型 | 推断 |
| `difficulty` | 难度 | 推断 |
| `started` | 任务开始时间（引擎时钟） | 推断 |
| `privacy` | `'public'` / `'friends'` / `'closed'` / `'friends_plus'` | 加入检查证明，名称推断 |
| `crossplay` | 0 关闭，1–4 平台代码 | 推断 |
| `nonce` | 创建时的随机数 | 证明 |

- `raw`：允许输出的属性原文，键为 `'p1'`、`'p5'` 这样的字符串。
- `mission`：任务描述（属性 10）解码后的字段和原始列表（`lists.a`–`f`）；任务修正项在其中某个列表里，哪个列表是哪种修正项尚未证实。只有房间成员能读到。

`D.lobby_search()`（大厅浏览结果）：`{refreshing, results}`
- 只有在本地玩家开始快速加入或 SOS 搜索后才有数据；搜索进行中 `refreshing = true`、结果为空。每次搜索完游戏会整表重建。
- 每个结果：`{owner（不透明）, host_matches_owner, version, phase, deployed, onboarding, crossplay, war, planet, difficulty, privacy, nonce, sos, props, marker}`。
  - `props` 是其余已识别的搜索属性原文（不含国家和房主 id；识别不了的键一律不输出）。
  - `marker`：房主写了 MDL3 标记（`string_key30`，格式 `hm1|<loader>|<ver>|<owner>`）且其中的 owner 与房主一致时，为 `{loader, version}`。
- **结果里没有房间人数**（游戏只拿它过滤满员房间，不保存）。
- 一次读取最多 50 个结果；Hub 内部最多每秒重读一次，两次之间返回上一次的列表，所以每帧调用也不会多花开销。

## 17. 背包状态 `D.backpacks()`（0.6 起）

租约（3 秒）。返回数组，每个玩家一项：`{peer, slot, is_local, name, backpack}`。没背背包、或这一帧读不到时 `backpack = nil`；某个玩家读取出错时那一项另有 `error`，不影响其他人。纯数据读取，不调用游戏代码。

**类型怎么判定**：游戏的 HUD 用同一个函数画所有背包的条，它按固定顺序检查背包实体挂了哪个组件，第一个命中的就是类型。Hub 照搬这个顺序（证明），不靠名字猜：

| 顺序 | `type` | 是什么 | `fill`（HUD 条的满度 0..1） |
|---|---|---|---|
| 1 | `'deposit'` | 补给背包、弹药背包、背包供弹武器的备弹包 | `count / max` |
| 1 | `'guard_dog'` | 守卫犬（同一个组件，但挂着一架无人机） | 无人机武器的弹量 `rounds / capacity`，或热量武器的 `1 − 热量 / 上限` |
| 2 | `'shield'` | 背包本身带护盾（推断为护盾发生器背包） | 被打破时 0，否则 `max(1, value) / max` |
| 3 | `'directional_shield'` | 背包控制一个独立的护盾实体（推断为定向护盾） | 同上，用那个护盾实体的值；没有关联的护盾实体时为 1（HUD 默认） |
| 4 | `'jump_pack'` / `'hover_pack'` / `'recharge'` | 冷却或燃料类背包 | `1 − 剩余 / 上限` |
| 5 | `'health'` | 背包自带血量（推断：防弹盾一类） | `health / health_max` |
| 6 | `'warp_pack'` | 传送背包 | `1 − 热量 / 100` |
| — | `'explosive'` | 带引信的炸弹背包（推断为地狱炸弹背包；HUD 不检查它，条恒为满） | `1` |
| — | `'other'` | 以上都不是 | `1`（HUD 默认） |

通用字段：`entity`（背包实体 id）、`owned`（背包属于本机玩家；标"仅主人"的字段只在 `owned = true` 时有值）、`type`、`fill`、`low`（HUD 会把条标红的状态：补给和守卫犬 `fill ≤ 0.31`；冷却类"没好且没在用"；传送背包热量达到 HUD 的警告线）。

组件命中但这一帧数据读不到时，`type` 照常给出（和 HUD 一样，第一个命中的组件决定类型），其余字段为 `nil`。

**各类型的字段**：

- `deposit`：`count, max`。
- `guard_dog`：
  - `refills = {count, max}`：背包里还能给无人机补几次弹（每次补给减 1，证明）；
  - `drone = {entity, weapon, health, health_max, docked, action, action_elapsed}`：
    - `weapon`：无人机武器 `{entity, ammo_type, rounds, capacity, mags, mags_max, heat = {value, max, locked}}`（同 §3 的弹药字段，同步数据，队友也有）；
    - `docked`：无人机挂在背包上（`false` = 已放出）。本机证明；队友身上推断（靠游戏的广播事件同步）；
    - `action`：无人机正在做的动作 `'launch'`（放出）/ `'dock'`（收回）/ `'reload'`（换弹）/ `'rearm'`（在背包补弹），以及已进行的秒数。没在做这几种动作时为 `nil`。
- `shield` / `directional_shield`：`shield = {value, max, up, broken, recharging, enabled, recharge_rate, delay_after_hit, delay_after_break, delay_left}`；`directional_shield` 另有 `active`（护盾正举着）和 `shield.entity`。
  - `value / max`：当前护盾值和上限；`up`：护盾已展开；`broken`：被打破（要等恢复延迟结束）；`recharging`：正在回充。
  - `recharge_rate`：每秒回充量；`delay_after_hit` / `delay_after_break`：被击中后 / 被打破后多久开始回充（秒，游戏设置数据）。
  - `delay_left`：距离开始回充还剩几秒，**只有背包主人本机有**，队友的为 `nil`（游戏只在主人那边倒计时）。
- `jump_pack`：`cooldown_left`（剩余冷却秒数，0 = 可用）、`cooldown`（总冷却秒数）、`ready`、`in_use`。队友的冷却是每台机器收到"开始冷却"广播后各自倒数的（推断）。
- `hover_pack`：`fuel, fuel_max`（剩余燃料，单位与冷却相同）、`ready`（燃料满）、`in_use`、`thrust`（正在喷）。**燃料只有背包主人本机准**，队友的 `fuel` / `fill` / `ready` / `low` 为 `nil`。
- `recharge`：同 `jump_pack` 的字段，用于有冷却组件但不是飞行背包的背包；仅主人（没找到它同步给其他机器的路径）。
- `health`：`health, health_max`（不处理游戏的血量覆盖组件；上限为 0 时读不到）。
- `warp_pack`：`heat`（0–100，每次传送增加）、`heat_max = 100`、`warn_at`（警告线）、`heat_per_warp`、`cooling`（每秒降温）、`cool_time`（按当前热量算的完全冷却秒数）。
- `explosive`：`explosive = {armed, started, fuse, detonated, remaining}`；`remaining`（剩余秒数）仅主人（引信只在主人那边倒数）。

| 项 | 状态 |
|---|---|
| 类型判定顺序、`fill` 公式、`low` 规则 | 证明（HUD 函数 0x169E8C0） |
| 护盾值 / 上限 / 打破 / 回充状态（队友也有） | 证明，同步数据 |
| 护盾回充速度、两种延迟 | 证明，游戏设置数据 |
| 护盾恢复倒计时 `delay_left` | 证明，仅主人 |
| 飞行背包冷却：本人 | 证明；队友：推断（每台机器各自倒数） |
| 其他冷却类背包（`recharge`） | 仅主人 |
| 飞行背包 / 悬浮背包区分（设置 +0x99） | 推断 |
| 悬浮背包燃料 | 仅主人 |
| 飞行背包 `in_use` / `thrust` | 证明，同步数据 |
| 传送背包热量和设置 | 证明，同步数据；上限 100 是游戏代码里的常数 |
| 守卫犬：无人机、补弹次数、武器弹药 | 证明，同步数据 |
| 守卫犬：`docked` / `action` | 本机证明，队友推断 |
| 炸弹背包引信 | 字段证明，"地狱炸弹背包带这个组件"是推断 |
| 哪个类型对应哪件具体装备（护盾发生器 / 定向护盾 / 防弹盾） | 推断（游戏不区分，只看组件） |
